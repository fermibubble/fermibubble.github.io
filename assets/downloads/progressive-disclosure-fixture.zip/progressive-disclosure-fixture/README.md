# Progressive disclosure contract fixture

Companion to Implementing Progressive Disclosure for Agent Tools. Python 3 standard library only; no network or credentials. All records and timestamps are synthetic.

Run from this directory:

```bash
python3 fixture.py --test
python3 fixture.py --output affected.json
```

The first command runs 13 deterministic contract tests. The second selects the latest finished snapshot, executes the article's SQL with bound values, writes a `rows` envelope to the requested file, and prints only a receipt. It reports payments with 3 affected instances and svc-unknown with 1; the latter has no ownership metadata. The complete export retains the snapshot's missing region-c and observation time.

`fixture.sql` contains an older snapshot, an unfinished newer capture, other release/environment records, and an unmatched service. `snapshot.sql` and `affected.sql` are the exact article queries. The inner-join variant in a test reproduces the silent omission.

`query_capture` builds a temporary catalog containing only the selected production capture and service directory. It binds the reserved snapshot_id from that context and rejects a parameter override. Tests verify that dropping the query predicates still cannot read other snapshots or environments from that catalog. This is a local demonstration of the pinned read set; it is not a secure service accepting untrusted SQL. The illustrative production --snapshot flag belongs to the proposed toolbox interface; the fixture selects its snapshot automatically.

Controlled MCP messages exercise catalog pagination (including a repeated cursor), protocol versus tool errors, preservation of content and structuredContent, and unknown source coverage. They do not connect to an MCP server. Application pagination is left in its original payload; receiving a response is not a claim that all application records were retrieved.

This is an executable contract fixture, not a production toolbox CLI or an agent benchmark. There are no model calls or token/latency comparisons. It does not implement authentication, gateway permissions, live transport, schema validation, byte-bounded streaming, or crash-safe file persistence. The tiny writer deliberately materializes rows so the receipt cases are easy to inspect. The catalog cache and search discussed in the article are proposed components, not implemented here.

For a real writer, drain the requested retrieval or mark it incomplete, stream within byte and time limits, and publish the final path only after the write succeeds. For a real SQL service, enforce identity and query budgets at the backend; do not use this in-memory fixture as a security boundary. Normalize database-native JSON and boolean values at the adapter boundary, as the fixture does for SQLite's text/integer storage.
