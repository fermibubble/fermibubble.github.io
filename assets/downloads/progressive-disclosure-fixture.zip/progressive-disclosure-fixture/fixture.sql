CREATE TABLE inventory_snapshots (
  snapshot_id TEXT PRIMARY KEY,
  observed_at TEXT NOT NULL,
  environment TEXT NOT NULL,
  capture_status TEXT NOT NULL,
  scope TEXT NOT NULL,
  coverage_complete INTEGER,
  missing_regions TEXT NOT NULL
);
CREATE TABLE runtime_instances (
  snapshot_id TEXT NOT NULL,
  instance_id TEXT NOT NULL,
  service_id TEXT NOT NULL,
  environment TEXT NOT NULL,
  release_id TEXT NOT NULL,
  PRIMARY KEY (snapshot_id, instance_id)
);
CREATE TABLE services (
  service_id TEXT PRIMARY KEY NOT NULL,
  name TEXT,
  owner_team TEXT
);
INSERT INTO inventory_snapshots VALUES
 ('snapshot-183', '2026-10-18T01:00:00Z', 'prod', 'finished',
  'authorized production inventory', 1, '[]'),
 ('snapshot-184', '2026-10-18T02:00:00Z', 'prod', 'finished',
  'authorized production inventory', 0, '["region-c"]'),
 ('snapshot-185', '2026-10-18T02:10:00Z', 'prod', 'running',
  'authorized production inventory', NULL, '[]');
INSERT INTO services VALUES ('svc-payments', 'payments', 'commerce');
INSERT INTO runtime_instances VALUES
 ('snapshot-184', 'i-1', 'svc-payments', 'prod', 'R42'),
 ('snapshot-184', 'i-2', 'svc-payments', 'prod', 'R42'),
 ('snapshot-184', 'i-3', 'svc-payments', 'prod', 'R42'),
 ('snapshot-184', 'i-4', 'svc-unknown', 'prod', 'R42'),
 ('snapshot-184', 'i-5', 'svc-payments', 'prod', 'R43'),
 ('snapshot-184', 'i-6', 'svc-payments', 'staging', 'R42'),
 ('snapshot-183', 'i-1', 'svc-payments', 'prod', 'R42');
