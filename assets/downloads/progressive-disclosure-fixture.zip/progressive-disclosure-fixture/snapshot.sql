SELECT snapshot_id, observed_at, scope,
       coverage_complete, missing_regions
FROM inventory_snapshots
WHERE environment = :environment
  AND capture_status = 'finished'
ORDER BY observed_at DESC, snapshot_id DESC
LIMIT 1;
