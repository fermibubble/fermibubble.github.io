SELECT
  i.service_id,
  s.name,
  s.owner_team,
  COUNT(*) AS affected_instances
FROM runtime_instances AS i
LEFT JOIN services AS s
  ON s.service_id = i.service_id
WHERE i.snapshot_id = :snapshot_id
  AND i.environment = :environment
  AND i.release_id = :release_id
GROUP BY i.service_id, s.name, s.owner_team
ORDER BY affected_instances DESC, i.service_id;
