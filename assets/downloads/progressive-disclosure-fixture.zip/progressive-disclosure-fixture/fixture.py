"""Executable article fixture: SQLite queries and controlled MCP response mapping.

No network, live MCP server, model calls, credentials, or production gateway.
This exercises contracts, not the complete proposed toolbox implementation.
"""
import argparse
import copy
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def database():
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    db.executescript((ROOT / "fixture.sql").read_text())
    return db


def latest_snapshot(db):
    rows = db.execute((ROOT / "snapshot.sql").read_text(), {"environment": "prod"}).fetchall()
    if not rows:
        raise ValueError("no finished production snapshot")
    snapshot = dict(rows[0])
    coverage = snapshot["coverage_complete"]
    snapshot["coverage_complete"] = None if coverage is None else bool(coverage)
    snapshot["missing_regions"] = json.loads(snapshot["missing_regions"])
    return snapshot


def query_capture(db, snapshot, query, params):
    """Fixture of a pinned read set, not a production SQL security boundary."""
    if "snapshot_id" in params:
        raise ValueError("snapshot_id is reserved by the capture context")
    scoped = sqlite3.connect(":memory:")
    scoped.row_factory = sqlite3.Row
    try:
        for table in ("runtime_instances", "services"):
            ddl = db.execute("SELECT sql FROM sqlite_master WHERE name = ?", (table,)).fetchone()[0]
            scoped.execute(ddl)
            if table == "runtime_instances":
                rows = db.execute("SELECT * FROM runtime_instances WHERE snapshot_id = ? AND environment = ?", (snapshot["snapshot_id"], "prod")).fetchall()
                scoped.executemany("INSERT INTO runtime_instances VALUES (?, ?, ?, ?, ?)", [tuple(row) for row in rows])
            else:
                rows = db.execute("SELECT * FROM services").fetchall()
                scoped.executemany("INSERT INTO services VALUES (?, ?, ?)", [tuple(row) for row in rows])
        scoped.execute("PRAGMA query_only = ON")
        bound = dict(params, snapshot_id=snapshot["snapshot_id"])
        return [dict(row) for row in scoped.execute(query, bound)]
    finally:
        scoped.close()


def affected(db, snapshot, release="R42", inner_join=False):
    query = (ROOT / "affected.sql").read_text()
    if inner_join:
        query = query.replace("LEFT JOIN", "JOIN")
    params = {"environment": "prod", "release_id": release}
    return query_capture(db, snapshot, query, params)


def write_result(rows, snapshot, output, limit=None):
    """A materialized test fixture; a production writer must stream and bound bytes."""
    selected = rows if limit is None else rows[:limit]
    complete = len(selected) == len(rows)
    output.write_text(json.dumps({"rows": selected}, indent=2) + "\n")
    receipt = {
        "execution": "succeeded",
        "result": {"path": str(output), "row_count": len(selected), "complete": complete},
        "source": copy.deepcopy(snapshot),
    }
    if not complete:
        receipt["result"]["incomplete_reason"] = "row_limit"
    return receipt, 0 if complete else 2


def mcp_result(response):
    """Map a known JSON-RPC response fixture; no transport/schema validator here."""
    if "error" in response:
        return {"execution": "failed", "error_kind": "protocol", "error": response["error"]}, 1
    result = copy.deepcopy(response["result"])
    if result.get("isError", False):
        return {"execution": "failed", "error_kind": "tool", "mcp": result}, 1
    return {
        "execution": "succeeded",
        "mcp": result,
        "source": {"coverage_complete": None},
    }, 0


def catalog(fetch):
    """Collect every tools/list page; do not print complete schemas by default."""
    cursor = None
    seen = set()
    definitions = []
    while True:
        page = fetch(cursor)
        definitions.extend(page["tools"])
        cursor = page.get("nextCursor")
        if cursor is None:
            return definitions
        if cursor in seen:
            raise ValueError("repeated tools/list cursor")
        seen.add(cursor)


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.db = database()
        self.addCleanup(self.db.close)
        self.snapshot = latest_snapshot(self.db)

    def test_latest_finished_snapshot_excludes_in_progress_capture(self):
        self.assertEqual(self.snapshot["snapshot_id"], "snapshot-184")
        self.assertEqual(self.snapshot["observed_at"], "2026-10-18T02:00:00Z")

    def test_query_retains_missing_owner_and_excludes_other_scope(self):
        self.assertEqual(affected(self.db, self.snapshot), [
            {"service_id": "svc-payments", "name": "payments", "owner_team": "commerce", "affected_instances": 3},
            {"service_id": "svc-unknown", "name": None, "owner_team": None, "affected_instances": 1},
        ])
        self.assertEqual(sum(r["affected_instances"] for r in affected(self.db, self.snapshot, inner_join=True)), 3)

    def test_release_parameter_is_a_value(self):
        self.assertEqual(affected(self.db, self.snapshot, "R42' OR 1=1 --"), [])

    def test_capture_catalog_stays_scoped_without_query_predicates(self):
        rows = query_capture(self.db, self.snapshot, "SELECT DISTINCT snapshot_id, environment FROM runtime_instances", {})
        self.assertEqual(rows, [{"snapshot_id": "snapshot-184", "environment": "prod"}])

    def test_capture_context_rejects_snapshot_parameter_override(self):
        with self.assertRaisesRegex(ValueError, "reserved"):
            query_capture(self.db, self.snapshot, "SELECT :snapshot_id", {"snapshot_id": "snapshot-183"})

    def test_complete_export_preserves_missing_region_and_timestamp(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "affected.json"
            receipt, code = write_result(affected(self.db, self.snapshot), self.snapshot, target)
            self.assertEqual(code, 0)
            self.assertTrue(receipt["result"]["complete"])
            self.assertFalse(receipt["source"]["coverage_complete"])
            self.assertEqual(receipt["source"]["missing_regions"], ["region-c"])
            self.assertEqual(receipt["source"]["observed_at"], "2026-10-18T02:00:00Z")
            self.assertEqual(len(json.loads(target.read_text())["rows"]), 2)

    def test_truncated_export_is_nonzero_and_explicit(self):
        with tempfile.TemporaryDirectory() as directory:
            receipt, code = write_result(affected(self.db, self.snapshot), self.snapshot, Path(directory) / "part.json", limit=1)
            self.assertEqual(code, 2)
            self.assertFalse(receipt["result"]["complete"])
            self.assertEqual(receipt["result"]["incomplete_reason"], "row_limit")

    def test_unknown_coverage_is_not_true(self):
        self.db.execute("UPDATE inventory_snapshots SET coverage_complete = NULL WHERE snapshot_id='snapshot-184'")
        self.assertIsNone(latest_snapshot(self.db)["coverage_complete"])

    def test_mcp_protocol_error_maps_to_nonzero(self):
        receipt, code = mcp_result({"error": {"code": -32602, "message": "Unknown tool"}})
        self.assertEqual((receipt["execution"], receipt["error_kind"], code), ("failed", "protocol", 1))

    def test_mcp_tool_error_maps_to_nonzero(self):
        result = {"isError": True, "content": [{"type": "text", "text": "Invalid time window"}]}
        receipt, code = mcp_result({"result": result})
        self.assertEqual((receipt["execution"], receipt["error_kind"], code), ("failed", "tool", 1))
        self.assertEqual(receipt["mcp"], result)

    def test_mcp_preserves_content_and_unknown_coverage(self):
        result = {"content": [{"type": "text", "text": "summary"}], "structuredContent": {"events": [], "next_page": "page-2"}}
        receipt, code = mcp_result({"result": result})
        self.assertEqual(code, 0)
        self.assertEqual(receipt["mcp"], result)
        self.assertIsNone(receipt["source"]["coverage_complete"])

    def test_catalog_consumes_all_pages(self):
        seen = []
        def fetch(cursor):
            seen.append(cursor)
            return {"tools": [{"name": "one"}], "nextCursor": "p2"} if cursor is None else {"tools": [{"name": "two"}]}
        self.assertEqual([x["name"] for x in catalog(fetch)], ["one", "two"])
        self.assertEqual(seen, [None, "p2"])

    def test_catalog_rejects_repeated_cursor(self):
        with self.assertRaisesRegex(ValueError, "repeated"):
            catalog(lambda cursor: {"tools": [], "nextCursor": "same"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("affected.json"))
    args = parser.parse_args()
    if args.test:
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(ContractTests)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        return 0 if result.wasSuccessful() else 1
    db = database()
    try:
        snapshot = latest_snapshot(db)
        receipt, code = write_result(affected(db, snapshot), snapshot, args.output)
        print(json.dumps(receipt, indent=2))
        return code
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
