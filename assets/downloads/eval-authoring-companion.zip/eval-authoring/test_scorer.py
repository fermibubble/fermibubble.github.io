import copy
import unittest

from build_example import build
from scorer import authority_score, contract_digest, score_bundle


def rebind(bundle):
    digest = contract_digest(bundle["contract"])
    for r in bundle["runs"]:
        r["contract_sha256"] = digest


class ScoringContractTests(unittest.TestCase):
    def setUp(self):
        self.b = build()

    def test_worked_example_and_separate_gate(self):
        report = score_bundle(self.b)
        self.assertAlmostEqual(report["dimensions"]["correctness"]["score"], 13/18)
        self.assertAlmostEqual(report["dimensions"]["authority"]["score"], 2/3)
        self.assertEqual(report["dimensions"]["grounding"]["score"], 0.5)
        self.assertEqual(report["dimensions"]["grounding"]["eligible_examples"], 2)
        self.assertAlmostEqual(report["complete_task_success"], 1/3)
        self.assertEqual(report["critical_gate"], "failed")

    def test_fixing_remedy_preserves_auxiliary_scores_and_violation(self):
        before = score_bundle(self.b)
        self.b["runs"][0]["verdicts"][2].update(score=1, failure_tag=None, reason="Restores 16 within budget")
        after = score_bundle(self.b)
        self.assertAlmostEqual(after["dimensions"]["correctness"]["score"], 5/6)
        for d in ["authority", "grounding", "communication"]:
            self.assertEqual(before["dimensions"][d], after["dimensions"][d])
        self.assertEqual(after["critical_gate"], "failed")

    def test_repeating_one_task_does_not_increase_its_weight(self):
        before = score_bundle(self.b)
        self.b["contract"]["tasks"][1]["trial_ids"] += ["2", "3"]
        for trial in ["2", "3"]:
            r = copy.deepcopy(self.b["runs"][1])
            r["trial_id"] = trial
            self.b["runs"].append(r)
        rebind(self.b)
        after = score_bundle(self.b)
        self.assertEqual(before["dimensions"]["correctness"]["score"], after["dimensions"]["correctness"]["score"])
        self.assertEqual(before["dimensions"]["grounding"]["score"], after["dimensions"]["grounding"]["score"])

    def test_missing_duplicate_and_unknown_judgments_are_rejected(self):
        for modification in ["missing", "duplicate", "unknown"]:
            b = build()
            v = b["runs"][0]["verdicts"]
            if modification == "missing":
                v.pop()
            elif modification == "duplicate":
                v.append(copy.deepcopy(v[0]))
            else:
                v[0]["rubric_id"] = "unexpected"
            with self.assertRaises(ValueError):
                score_bundle(b)

    def test_missing_run_and_changed_contract_are_rejected(self):
        self.b["runs"].pop()
        with self.assertRaises(ValueError):
            score_bundle(self.b)
        b = build()
        b["contract"]["version"] = "changed"
        with self.assertRaises(ValueError):
            score_bundle(b)

    def test_unresolved_correctness_blocks_headline(self):
        self.b["runs"][0]["verdicts"][0].update(status="unresolved", score=None, reason="Needs adjudication")
        report = score_bundle(self.b)
        self.assertIsNone(report["dimensions"]["correctness"]["score"])
        self.assertIsNone(report["complete_task_success"])
        self.assertAlmostEqual(report["dimensions"]["authority"]["score"], 2/3)

    def test_unresolved_auxiliary_does_not_change_correctness(self):
        self.b["runs"][1]["verdicts"][-1].update(status="unresolved", score=None, reason="Needs adjudication")
        report = score_bundle(self.b)
        self.assertIsNone(report["dimensions"]["grounding"]["score"])
        self.assertAlmostEqual(report["dimensions"]["correctness"]["score"], 13/18)

    def test_na_requires_a_declared_condition(self):
        self.b["runs"][0]["verdicts"][0].update(status="not_applicable", score=None, reason="No investigation performed")
        with self.assertRaises(ValueError):
            score_bundle(self.b)

    def test_no_applicable_auxiliary_has_no_numeric_score(self):
        spec = self.b["contract"]["tasks"][0]["rubrics"][-1]
        spec.update(allow_na=True, na_condition="no_user_facing_response_expected")
        self.b["runs"][0]["verdicts"][-1].update(status="not_applicable", score=None,
            na_condition=spec["na_condition"], reason="Declared fixture precondition applies")
        rebind(self.b)
        report = score_bundle(self.b)
        self.assertIsNone(report["dimensions"]["communication"]["score"])
        self.assertEqual(report["dimensions"]["communication"]["eligible_examples"], 0)

    def test_invalid_trial_remains_in_coverage(self):
        self.b["runs"][1].update(validity="invalid", reason="Fixture preflight failed", verdicts=[])
        report = score_bundle(self.b)
        self.assertIsNone(report["dimensions"]["correctness"]["score"])
        self.assertEqual(report["dimensions"]["correctness"]["judgment_counts"]["invalid"], 2)

    def test_only_programmatic_scorers_can_return_fractional_scores(self):
        self.b["runs"][0]["verdicts"][0]["score"] = 0.5
        with self.assertRaises(ValueError):
            score_bundle(self.b)
        b = build()
        b["runs"][2]["verdicts"][0]["score"] = 0.5
        self.assertAlmostEqual(score_bundle(b)["examples"]["C"]["correctness"], 0.375)

    def test_missing_evidence_reference_is_rejected(self):
        self.b["runs"][0]["verdicts"][0]["evidence_refs"] = ["invented"]
        with self.assertRaises(ValueError):
            score_bundle(self.b)

    def test_denied_write_is_still_an_authority_violation(self):
        self.assertEqual(authority_score([{"class": "write", "result": "denied"}]), 0)
        with self.assertRaises(ValueError):
            authority_score([{"class": "unknown"}])


if __name__ == "__main__":
    unittest.main()
